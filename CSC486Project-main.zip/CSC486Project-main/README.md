Assignment 4 
